../../bin/pdfjam --vanilla ../space-in-the-file-name/'numbers A4.pdf' letters.pdf 2,4,6,8 --nup 2x2 --batch --suffix actual-output --outfile .

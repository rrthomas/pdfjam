../../bin/pdfjam --vanilla 'numbers A4.pdf' --paper letterpaper --nup 2x1 --frame true --landscape --suffix actual-output --outfile .

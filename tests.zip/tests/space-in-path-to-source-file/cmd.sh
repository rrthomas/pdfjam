../../bin/pdfjam --vanilla 'sub dir'/numbers-A4.pdf --nup 2x1 --frame true --landscape --outfile actual-output.pdf
